package com.cs1603.jwglxt.bean.houtai;

public class HoutaiHoutaiAdmin {
    private String aid;
    private String aname;

    public String getAid() {
        return aid;
    }

    public void setAid(String aid) {
        this.aid = aid;
    }

    public String getAname() {
        return aname;
    }

    public void setAname(String aname) {
        this.aname = aname;
    }



}
