package com.cs1603.jwglxt.bean.houtai;

public class HoutaiRizhi {
    private String Log_name ;
    private String Pos;
    private String Event_type;
    private String Server_id;
    private String End_log_pos;
    private String Info;
    public String getLog_name() {
        return Log_name;
    }

    public void setLog_name(String Log_name) {
        this.Log_name = Log_name;
    }
    public String getPos() {
        return Pos;
    }

    public void setPos(String Pos) {
        this.Pos = Pos;
    }
    public String getEvent_type() {
        return Pos;
    }

    public void setEvent_type(String Event_type) {
        this.Event_type = Event_type;
    }
    public String getServer_id() {
        return Server_id;
    }

    public void setServer_id(String Server_id) {
        this.Server_id = Server_id;
    }
    public String getEnd_log_pos() {
        return End_log_pos;
    }

    public void setEnd_log_pos(String End_log_pos) {
        this.End_log_pos = End_log_pos;
    }
    public String getInfo() {
        return Info;
    }

    public void setInfo(String Info) {
        this.Info = Info;
    }



}
