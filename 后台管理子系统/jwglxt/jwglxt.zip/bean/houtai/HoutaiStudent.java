package com.cs1603.jwglxt.bean.houtai;

import java.util.Date;

public class HoutaiStudent {
    private String sid;
    private String sname;
    private String ssta;
    private String ssex;
    private String sclass;
    private String major;
    private String scollege;
    private String snat;
    private String sres;
    private String smail;
    private String spol;
    private String stel;
    private String sin;
    private String sout;
    private Date sbir;

    public String getSid() {
        return sid;
    }

    public void setSid(String sid) {
        this.sid = sid;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getSsta() {
        return ssta;
    }

    public void setSsta(String ssta) {
        this.ssta = ssta;
    }

    public String getSsex() {
        return ssex;
    }

    public void setSsex(String ssex) {
        this.ssex = ssex;
    }

    public String getSclass() {
        return sclass;
    }

    public void setSclass(String sclass) {
        this.sclass = sclass;
    }

    public String getMajor() {
        return major;
    }

    public void setMajor(String major) {
        this.major = major;
    }

    public String getScollege() {
        return scollege;
    }

    public void setScollege(String scollege) {
        this.scollege = scollege;
    }

    public String getSnat() {
        return snat;
    }

    public void setSnat(String snat) {
        this.snat = snat;
    }

    public String getSres() {
        return sres;
    }

    public void setSres(String sres) {
        this.sres = sres;
    }

    public String getSmail() {
        return smail;
    }

    public void setSmail(String smail) {
        this.smail = smail;
    }

    public String getSpol() {
        return spol;
    }

    public void setSpol(String spol) {
        this.spol = spol;
    }

    public String getStel() {
        return stel;
    }

    public void setStel(String stel) {
        this.stel = stel;
    }

    public String getSin() {
        return sin;
    }

    public void setSin(String sin) {
        this.sin = sin;
    }

    public String getSout() {
        return sout;
    }

    public void setSout(String sout) {
        this.sout = sout;
    }

    public Date getSbir() {
        return sbir;
    }

    public void setSbir(Date sbir) {
        this.sbir = sbir;
    }


}
