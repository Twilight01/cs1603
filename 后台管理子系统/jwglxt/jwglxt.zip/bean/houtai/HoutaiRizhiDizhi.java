package com.cs1603.jwglxt.bean.houtai;

import java.util.Date;

public class HoutaiRizhiDizhi {
    private String Log_name;
    private String File_size;
    private String Encrypted;

    public String getLog_name() {
        return Log_name;
    }

    public void setLog_name(String Log_name) {
        this.Log_name = Log_name;
    }

    public String getFile_size() {
        return File_size;
    }

    public void setFile_size(String File_size) {
        this.File_size = File_size;
    }
    public String getEncrypted() {
        return Encrypted;
    }

    public void setEncrypted(String Encrypted) {
        this.Encrypted = Encrypted;
    }

}
