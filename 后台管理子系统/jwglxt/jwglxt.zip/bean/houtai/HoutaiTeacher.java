package com.cs1603.jwglxt.bean.houtai;

public class HoutaiTeacher {
    private String tid;
    private String tname;
    private String tcollege;
    private String post;
    private String tnat;
    private String tres;
    private String tmail;
    private String tpol;
    private String ttel;
    private String tin;

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getTname() {
        return tname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public String getTcollege() {
        return tcollege;
    }

    public void setTcollege(String tcollege) {
        this.tcollege = tcollege;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getTnat() {
        return tnat;
    }

    public void setTnat(String tnat) {
        this.tnat = tnat;
    }

    public String getTres() {
        return tres;
    }

    public void setTres(String tres) {
        this.tres = tres;
    }

    public String getTmail() {
        return tmail;
    }

    public void setTmail(String tmail) {
        this.tmail = tmail;
    }

    public String getTpol() {
        return tpol;
    }

    public void setTpol(String tpol) {
        this.tpol = tpol;
    }

    public String getTtel() {
        return ttel;
    }

    public void setTtel(String ttel) {
        this.ttel = ttel;
    }

    public String getTin() {
        return tin;
    }

    public void setTin(String tin) {
        this.tin = tin;
    }


}
