package com.cs1603.jwglxt.bean.houtai;

public class HoutaiVisit_inf {
    private String sessionId;
    private String m_user;
    private String ip;
    private String m_page;
    private String m_time;

    public String getsessionId() {
        return sessionId;
    }

    public void setsessionId(String sessionId) {
        this.sessionId = sessionId;
    }
    public String getm_user() {
        return m_user;
    }

    public void setm_user(String m_user) {
        this.m_user = m_user;
    }
    public String getip() {
        return ip;
    }

    public void setip(String ip) {
        this.ip = ip;
    }
    public String getm_page() {
        return m_page;
    }

    public void setm_page(String m_page) {
        this.m_page = m_page;
    }
    public String getm_time() {
        return m_time;
    }

    public void setm_time(String m_time) {
        this.m_time = m_time;
    }

}
