

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Myservlet
 */
@WebServlet("/Myservlet")
public class Myservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
	
    public Myservlet() {
    
        super();
    	//System.out.println("fassfd");
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
		request.setCharacterEncoding("UTF-8");
		
		String id=request.getParameter("id");
		String number=request.getParameter("number");
		String name=request.getParameter("name");
		String teacher=request.getParameter("teacher");
		String stumajor=request.getParameter("stumajor");
		String type=request.getParameter("type");
		int capacity=Integer.parseInt(request.getParameter("capacity")) ;
		
		//PrintWriter out = response.getWriter();
		//out.println("<h1>" +  "\n���������Ϣ�ǣ�"); 
		System.out.println(capacity);
		DB db=new DB();
		boolean bo=db.Add_DB(id, number, name,teacher,stumajor,type,capacity);
		if(bo==true)
		 response.sendRedirect("add_course.html");
		else {
			PrintWriter out = response.getWriter();
			out.println("<h1>" +  "\n���ִ���"); 
		}
	}

	/**
	 * @see HttpServlet#doDelete(HttpServletRequest, HttpServletResponse)
	 */
	protected void doDelete(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	}

}
