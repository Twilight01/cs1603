import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

import com.sun.glass.events.WindowEvent;

public class DB {

	String URL="jdbc:mysql://localhost:3306/db";
	String name="root";
	String psd="root";
	 Connection connect;
	public DB() {
		
	}
	public DB(String url,String n,String p) {
		URL=url;
		name=n;
		psd=p;
	}
	public void connect_DB() {
		 try {
			Class.forName("com.mysql.jdbc.Driver");
		} catch (ClassNotFoundException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		} 
		 try {
			connect = DriverManager.getConnection(
			          URL,name,psd);
			System.out.println("Success connect Mysql server!");
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
		 
	}
public void close_DB() {
		try {
			connect.close();
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			e.printStackTrace();
		}
	}
	public boolean Add_DB(String id,String number,String name,String teacher,String stumajor,String type,int capacity ) {
		connect_DB();
		try {
			PreparedStatement stmt=connect.prepareStatement("INSERT INTO paikepre VALUES(?,?,?,?,?,?,?)");
			
			stmt.setString(1, id);
			stmt.setString(2, number);
			stmt.setString(3, name);
			stmt.setString(4, stumajor);
			stmt.setString(5, type);
			stmt.setString(6, teacher);
			stmt.setLong(7, capacity);
			stmt.executeUpdate();
			stmt.close();
			
			//WindowEvent.history.back(-1);
		} catch (SQLException e) {
			// TODO �Զ����ɵ� catch ��
			close_DB();
			
			e.printStackTrace();
			return false;
		}
		close_DB();
		return true;
	}
		
}
