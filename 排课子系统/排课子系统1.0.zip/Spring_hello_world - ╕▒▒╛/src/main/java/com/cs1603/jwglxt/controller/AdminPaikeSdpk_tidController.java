package com.cs1603.jwglxt.controller;
/**
 * url：api/admin/sdpk_tid
 * 参数：tid(Int)
 * 返回：原来的时间time1和教室地点classid，课程名cname,面向专业cmajor
 *
 * */
import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_for_chaxun;
import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_tid_for_change;
import com.cs1603.jwglxt.bean.paike.Flag;
import com.cs1603.jwglxt.service.AdminPaikeSdpk_tidService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;

@Controller
public class AdminPaikeSdpk_tidController {
    @Resource
   private AdminPaikeSdpk_tidService adminPaikeSdpk_tidService;
    @CrossOrigin
    @ResponseBody
    @RequestMapping("api/admin/sdpk_tid")
        public Course_for_qianduan_tid_for_change[] login(@RequestBody Flag temp)
    {
        String tid = temp.getTid();
        System.out.println(tid);
       return adminPaikeSdpk_tidService.teacher_find_by_id(tid);
    }

}
