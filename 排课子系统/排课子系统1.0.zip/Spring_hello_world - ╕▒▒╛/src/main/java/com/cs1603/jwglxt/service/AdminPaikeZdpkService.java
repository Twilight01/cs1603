package com.cs1603.jwglxt.service;

import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Course_zdpk;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import com.cs1603.jwglxt.mapper.AdminPaikeZdpkMapper;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class AdminPaikeZdpkService {
    @Resource
    private AdminPaikeZdpkMapper adminPaikeZdpkMapper;

    public Course_zdpk[] is_alreay_paike_()
    {

        return adminPaikeZdpkMapper.is_alreay_paike();
    }
}
