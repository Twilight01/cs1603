package com.cs1603.jwglxt.service;

import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_for_chaxun;
import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_tid_for_change;
import com.cs1603.jwglxt.bean.paike.Result;
import com.cs1603.jwglxt.mapper.AdminPaikeSdpk_tidMapper;
import com.cs1603.jwglxt.result.ResultUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class AdminPaikeSdpk_tidService {
    @Resource
    private AdminPaikeSdpk_tidMapper adminPaikeSdpk_tidMapper;
    public Course_for_qianduan_tid_for_change[] teacher_find_by_id(String tid)
    {
        return adminPaikeSdpk_tidMapper.findall(tid);
    }
}
