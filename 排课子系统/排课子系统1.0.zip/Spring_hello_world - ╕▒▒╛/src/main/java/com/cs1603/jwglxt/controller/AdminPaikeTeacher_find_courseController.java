package com.cs1603.jwglxt.controller;
/**
 * 管理员查询老师课表：
 * url：api/admin/teacher_find_course
 * 参数：year(String),semester(String),tid(String)
 * 返回：json该专业当前学年学期课表（String[][]）
 * */

import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_for_chaxun;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import com.cs1603.jwglxt.bean.paike.Result;
import com.cs1603.jwglxt.service.AdminPaikeTeacher_find_courseService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Controller
public class AdminPaikeTeacher_find_courseController {
    @Resource
    private AdminPaikeTeacher_find_courseService adminPaikeTeacher_find_courseService;
    @CrossOrigin
    @ResponseBody
    @RequestMapping("api/admin/teacher_find_course")
//    public Result<Coursehistory[]> login(@RequestBody Coursehistory requestUser) {
//        String Year = requestUser.getYear();
//        Integer semester = requestUser.getSemester();
//        System.out.println(semester);
//        String tid = requestUser.getTid();
//        System.out.println("admin"+Year);
//        return adminPaikeTeacher_find_courseService.admin_tearch_find(Year,semester,tid);
//    }
        public Course_for_qianduan_for_chaxun[][] login( @RequestBody Coursehistory requestUser)
    {
       String Year = requestUser.getYear();
        Integer semester = requestUser.getSemester();
        System.out.println(semester);
        String tid = requestUser.getTid();
        System.out.println("admin"+Year);
        Course_for_qianduan_for_chaxun [][] res  = new Course_for_qianduan_for_chaxun[7][13];   //初始化定义 空值为null
        for(int i=0;i<7;i++)
            for(int j=0;j<13;j++)
            {
                Course_for_qianduan_for_chaxun temp = new  Course_for_qianduan_for_chaxun("","","","","","","");
                res[i][j]=temp;
            }
        Course_for_qianduan_for_chaxun[] data_from_sql=   adminPaikeTeacher_find_courseService.admin_tearch_find(Year,semester,tid);
        Map<String, Integer> xingqiji_id = new HashMap<String, Integer>();
        xingqiji_id.put("一",1);xingqiji_id.put("二",2);xingqiji_id.put("三",3);xingqiji_id.put("四",4);xingqiji_id.put("五",5);xingqiji_id.put("六",6);xingqiji_id.put("七",7);
        for(int i=0;i<data_from_sql.length;i++)
        {
           String time1[] = new String[10];
           String time2[]= new String[10];
           time1 = data_from_sql[i].getTime1().split(",");
           time2 = data_from_sql[i].getTime2().split(",");
            for(int j=1;j<time1.length;j++)
            {
                int xingqiji1 = xingqiji_id.get(time1[0]);
                int shangkeshijian = Integer.parseInt(time1[j])  ;
                res [xingqiji1-1][shangkeshijian-1] = data_from_sql[i];
            }
            for(int j=1;j<time2.length;j++)
            {
                int xingqiji2 = xingqiji_id.get(time2[0]);
                int shangkeshijian = Integer.parseInt(time2[j])  ;
                res [xingqiji2-1][shangkeshijian-1] = data_from_sql[i];
            }

        }
       return res;
    }
}
