package com.cs1603.jwglxt.mapper;
import com.cs1603.jwglxt.bean.paike.*;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface AdminPaikeSdpk_chooseMapper {
    @Select("select course.id,teacher.tid,tname,cname,time1,time2,classroom.classname,cmajor  from course,teacher,classroom where teacher.tid = course.tid and course.classid=classroom.classid and course.id=#{id}")
    public Course_for_qianduan_tid_for_change[] findall(@Param("id") String id);
}


