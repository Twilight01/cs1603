package com.cs1603.jwglxt.bean.paike;

public class Flag
{
    public String flag;
    public int id;
    public String tid;
    public Flag(String flag, int id,String tid) {
        this.flag = flag;
        this.id = id;
        this.tid=tid;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getFlag() {
        return flag;
    }

    public int getId() {
        return id;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public void setId(int id) {
        this.id = id;
    }
}
