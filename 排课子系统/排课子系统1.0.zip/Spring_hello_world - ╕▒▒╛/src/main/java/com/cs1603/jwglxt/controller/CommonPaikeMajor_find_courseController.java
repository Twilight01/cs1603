package com.cs1603.jwglxt.controller;
/**
 * 每个人都可以查专业课表：
 * url：/api/common/major_find_course
 * 参数：year(String),semester(String),cmajor(String)
 * 返回：json某年的某专业的课表（String[][]）
 * */

import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_for_chaxun;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import com.cs1603.jwglxt.bean.paike.Result;
import com.cs1603.jwglxt.service.AdminPaikeTeacher_find_courseService;
import com.cs1603.jwglxt.service.CommonPaikeMajor_find_courseService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.util.HashMap;
import java.util.Map;

@Controller
public class CommonPaikeMajor_find_courseController {
    @Resource
    private CommonPaikeMajor_find_courseService commonPaikeMajor_find_courseService;
    @CrossOrigin
    @ResponseBody
    @RequestMapping("/api/common/major_find_course")
    public Course_for_qianduan_for_chaxun[][] test()
    {
      /*  String Year = Userbody.getYear();
        Integer semester = Userbody.getSemester();
        String cmajor = Userbody.getCmajor();*/
        Course_for_qianduan_for_chaxun[][] res  = new Course_for_qianduan_for_chaxun[7][13];   //初始化定义 空值为null
        for(int i=0;i<7;i++)
            for(int j=0;j<13;j++)
            {
                Course_for_qianduan_for_chaxun temp = new  Course_for_qianduan_for_chaxun("","","","","","","");
                res[i][j]=temp;
            }
        Course_for_qianduan_for_chaxun[] data_from_sql=   commonPaikeMajor_find_courseService.major_find_course ("2016",1,"计算机");
        Map<String, Integer> xingqiji_id = new HashMap<String, Integer>();
        System.out.println("2016");
        xingqiji_id.put("一",1);xingqiji_id.put("二",2);xingqiji_id.put("三",3);xingqiji_id.put("四",4);xingqiji_id.put("五",5);xingqiji_id.put("六",6);xingqiji_id.put("七",7);
        for(int i=0;i<data_from_sql.length;i++)
        {
            String time1[] = new String[10];
            String time2[]= new String[10];
            time1 = data_from_sql[i].getTime1().split(",");
            time2 = data_from_sql[i].getTime2().split(",");
            for(int j=1;j<time1.length;j++)
            {
                int xingqiji1 = xingqiji_id.get(time1[0]);
                int shangkeshijian = Integer.parseInt(time1[j])  ;
                res [xingqiji1-1][shangkeshijian-1] = data_from_sql[i];
            }
            for(int j=1;j<time2.length;j++)
            {
                int xingqiji2 = xingqiji_id.get(time2[0]);
                int shangkeshijian = Integer.parseInt(time2[j])  ;
                res [xingqiji2-1][shangkeshijian-1] = data_from_sql[i];
            }

        }
        return res;
    }
}
