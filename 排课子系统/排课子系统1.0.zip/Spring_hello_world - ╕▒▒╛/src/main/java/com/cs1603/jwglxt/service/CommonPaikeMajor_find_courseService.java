package com.cs1603.jwglxt.service;


import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_for_chaxun;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import com.cs1603.jwglxt.bean.paike.Result;
import com.cs1603.jwglxt.mapper.CommonPaikeMajor_find_courseMapper;
import com.cs1603.jwglxt.result.ResultUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class CommonPaikeMajor_find_courseService {
    @Resource
    private CommonPaikeMajor_find_courseMapper commonPaikeMajor_find_courseMapper;
    public Course_for_qianduan_for_chaxun[] major_find_course(String year, Integer semester, String cmajor)
    {
        return  commonPaikeMajor_find_courseMapper.major_find_course(year,semester,cmajor);
    }

}
