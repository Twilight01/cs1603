package com.cs1603.jwglxt.bean.paike;

public class Course_for_qianduan_tid_for_change {
    private String tid;
    private String tname;
    private String cname;
    private String time1;
    private String time2;
    private String classname;
    private String cmajor;
    private String id;

    public Course_for_qianduan_tid_for_change(String tid, String tname, String cname, String time1, String time2, String classname, String cmajor, String id) {
        this.tid = tid;
        this.tname = tname;
        this.cname = cname;
        this.time1 = time1;
        this.time2 = time2;
        this.classname = classname;
        this.cmajor = cmajor;
        this.id = id;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTid() {
        return tid;
    }

    public String getTname() {
        return tname;
    }

    public String getCname() {
        return cname;
    }

    public String getTime1() {
        return time1;
    }

    public String getTime2() {
        return time2;
    }

    public String getClassname() {
        return classname;
    }

    public String getCmajor() {
        return cmajor;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public void setTime1(String time1) {
        this.time1 = time1;
    }

    public void setTime2(String time2) {
        this.time2 = time2;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public void setCmajor(String cmajor) {
        this.cmajor = cmajor;
    }
}
