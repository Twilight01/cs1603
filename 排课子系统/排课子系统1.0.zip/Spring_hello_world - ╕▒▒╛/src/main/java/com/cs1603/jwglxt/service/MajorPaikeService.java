package com.cs1603.jwglxt.service;
import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import com.cs1603.jwglxt.bean.paike.Result;
import com.cs1603.jwglxt.mapper.MajorPaikeMapper;
import com.cs1603.jwglxt.result.ResultUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class MajorPaikeService {
    @Resource
    private MajorPaikeMapper majorPaikeMapper;
    public Result<Coursehistory> major_find(String year, Integer semester, String cmajor)
    {
        return  ResultUtil.success(majorPaikeMapper.major_find(year,semester,cmajor));
    }
}
