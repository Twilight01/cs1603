package com.cs1603.jwglxt.controller;
/**
 * url：api/admin/sdpk_choose
 * 参数：tid(Int)
 * 返回：原来的时间time1和教室地点classid，课程名cname,面向专业cmajor
 *
 * */
import com.cs1603.jwglxt.bean.paike.*;
import com.cs1603.jwglxt.result.ResultUtil;
import com.cs1603.jwglxt.service.AdminPaikeSdpk_chooseService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import java.sql.*;

import java.io.*;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@Controller
public class AdminPaikeSdpk_chooseController
{

    @Resource
    private AdminPaikeSdpk_chooseService adminPaikeSdpk_chooseService;
    @CrossOrigin
    @ResponseBody
    @RequestMapping("api/admin/sdpk_choose")
    public Result<Course_for_qianduan_tid_for_change> login(@RequestBody Course_for_qianduan_tid_for_change requestUser) throws Exception {

        //String id="254";
        String id = requestUser.getId();        //接受id值
        System.out.println(id);
        new Main(id);       //重新排课
        return ResultUtil.success(adminPaikeSdpk_chooseService.new_course_after_chongxinpaike(id)   );   //把重新排课的结果返回前端
    }
}
class Main
{
    Random rand = new Random();
    int [][][][] class_is_use_information = new int[1000][7][4][100];   // [阶教101[大一][周一][第一个时间段][第15周]
    int [][][][][] major_is_busy_information = new int[1000][4][7][4][100]; // [计科][大一][周一][第一个时间段][第15周]
    int [][][][] teacher_is_busy_information = new int[1000][7][4][100];    // [tid][大一][周一][第一个时间段][第15周]
    int [] course_id_is_use = new int [1000];
    //        major_id.get(tmp) 对应major的序号id
    Map<String, Integer> major_id = new HashMap<String, Integer>();
    int major_num=0; // 所有专业数

    String[][] class_room_information = new String[1000][3];     //二维数组 存放着教室信息
    //[0]{1,A阶101，180      }
    //[1]{2,A阶102，180     }
    char[] chinese_sign = new char[]{'一','二','三','四','五','六','七'};
    int class_room_num =0;  //记录教室数量
    Connection conn ;
    Statement state;
    //从数据库提取信息，每次读出二维String

    void save_txt( ) throws IOException {
        File file1 = new File("./class_is_use_information.txt");
        File file2 = new File("./major_is_busy_information.txt");
        File file3 = new File("./teacher_is_busy_information.txt");
        FileWriter out1 = new FileWriter(file1);
        FileWriter out2 = new FileWriter(file2);
        FileWriter out3 = new FileWriter(file3);
        for(int i=0;i<1000;i++)
            for(int j=0;j<7;j++)
                for(int z=0;z<4;z++)
                    for(int t=0;t<100;t++) {
                        out1.write(class_is_use_information[i][j][z][t] + "");

                        out3.write( teacher_is_busy_information[i][j][z][t]+"");
                    }
        for(int i=0;i<1000;i++)
            for(int p=0;p<4;p++)
                for(int j=0;j<7;j++)
                    for(int z=0;z<4;z++)
                        for(int t=0;t<100;t++) {
                            out2.write( major_is_busy_information[i][p][j][z][t]+"");
                        }




        out1.close();
        out2.close();
        out3.close();

    }
    public String[][] get_sql_information_to_array(String sql) throws Exception
    {
        ResultSet sql_handle=state.executeQuery(sql);
        sql_handle.last();
        int hangshu = sql_handle.getRow();
//        System.out.println("行数"+hangshu);
        sql_handle.beforeFirst();
        ResultSetMetaData sql_handle_data = sql_handle.getMetaData();
        int columncount = sql_handle_data.getColumnCount();
        String temp[][] = new String[hangshu][columncount];
        int hang = 0;
        while(sql_handle.next())
        {
            String temp_hang[]=new String[columncount];
            for(int i=0;i<columncount;i++)
            {
                temp_hang[i] = sql_handle.getString(i+1);
//                System.out.println(temp_hang[i]);
            }
            temp[hang] = temp_hang;
            hang++;
        }
        return temp;
    }
    public String[] class_room_fix_your_need(  int  rongliang  ) throws Exception
    {
        String sql = "select classid from classroom where classvol <="+rongliang;
//        System.out.println(sql);
        String temp[][]=new String [50][50];
        temp=get_sql_information_to_array(sql);
        String res[] = new String [temp.length];
        for(int i=0;i<temp.length;i++)
        {
            res[i]=temp[i][0];
        }
        return res;
    }
    int daji_judge(String nianji)
    {
        int nianji_id=0;
        if (nianji.equals("大一"))  nianji_id=0;
        if (nianji.equals("大二"))  nianji_id=1;
        if (nianji.equals("大三"))  nianji_id=2;
        if (nianji.equals("大四"))  nianji_id=3;
        return nianji_id;
    }
    String timeinterToString(int t, int jie)
    {
        String ans="";
        if (jie==2)
        {
            if (t==0) ans="1,2";
            if (t==1) ans="4,5";
            if (t==2) ans="7,8";
            if (t==3) ans="11,12";
        }
        else
        {
            if (t==0) ans="1,2,3";
            if (t==1) ans="4,5";
            if (t==2) ans="7,8,9";
            if (t==3) ans="11,12,13";
        }

        return ans;
    }
    public String[] erwei_to_yiwei(String temp[][])
    {
        String res[] = new String [temp.length];
        for(int i=0;i<temp.length;i++)
        {
            res[i] = temp[i][0];
        }
        return res;
    }
    //通过String数组录入sql语句对数据库进行添加
    public void change_sql(String temp[]) throws Exception
    {
        String sql_change="";
        for(int temp_i = 1;temp_i <=12;temp_i++)
        {
            sql_change = sql_change+"'"+temp[temp_i]+"',";
        }
        sql_change = sql_change+"'"+temp[13]+"'";
        String insert_sql="INSERT INTO `1603_`.`course`(`cnum`, `cname`, `cmajor`, `ctype`, `tid`, `call`, `cstart`, `cend`, `credit`, `time1`, `time2`, `classid`, `cnow`) VALUES ( "+sql_change+")";
        state.executeUpdate(insert_sql);
    }

    //   排专业1的课表，对于每一门课调用random_course
    public void random_course(String id,String time1,String time2,String majors,String tid_,String call,String cstart,String cend,int fre)throws Exception
    {
        int tid=Integer.parseInt(tid_);
//          id：对应coursesorting的id课程序号
//          fre：上课频率
//          majors：需要上该课的所有专业
//          tid：教师编号
//          vol：该课程容量
//          先随机星期几，再随机时间段
//          根据课程容量，随机教室
//          fre=6 即3*2;fre=4 即2*2;fre=3 即3*1;fre=2 即2*1
//        for (String tmp_:tmp)
//        {
//            System.out.print(tmp_+" ");
//        }
//        System.out.println();
        String [] ans=new String[100];
        String class_room_fix_need[] = new String[1000]; //符合容量的教室编号
        String class_room_fix_one_time[] = new String[1000]; //符合第一次时间的教室编号
        int class_room_fix_one_time_num=0;

        class_room_fix_need = class_room_fix_your_need(Integer.parseInt(call));
        int rand_one_xingqiji=0;
        String[] major = majors.split("，");
        while (rand_one_xingqiji<=120) //随机次数
        {
            if(rand_one_xingqiji==120)
            {
                System.out.println("ERROR");
            }
            int one_xingqiji=rand.nextInt(5);
            int rand_one_time_inter=0;
            rand_one_xingqiji++;
            while(rand_one_time_inter<=24)
            {
                int one_time_inter=rand.nextInt(4);
                if ((fre==3 || fre==6) && one_time_inter==1) continue ;
                boolean flag_is_busy=true;
                rand_one_time_inter++;
                for (String major_ : major) //查专业是否有空
                {
//                    System.out.println(123+ major_id.get(major_));
//                    System.out.println("专业？："+major_.substring(2));
                    int major_id_ = major_id.get(major_.substring(2)).intValue();
//                    System.out.println(major_id_);
                    String nianji = major_.substring(0,2);
                    int nianji_id=0;
                    nianji_id=daji_judge(nianji);


                    //大二化学专业 从第二个开始截取 即为化学专业
                    if (major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0]==0) //如果专业有空则继续判断
                    {
                        continue;
                    }
                    else //有专业没空，flag标记跳出
                    {
                        flag_is_busy=false;
                        break;
                    }
                }
                if (teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0]==1) {
                    flag_is_busy=false;
                }
                if (flag_is_busy==false)
                {
                    break;
                }
//以上无错
                for (int i=0;i<class_room_fix_need.length;i++) //找出所有满足容量里符合时间的教室
                {
                    int class_room_i_id;
                    String sql_class_room_id="select classid from classroom where classid="+class_room_fix_need[i];
                    ResultSet class_room_ids=state.executeQuery(sql_class_room_id);
                    while (class_room_ids.next())
                    {
                        class_room_i_id=class_room_ids.getInt("classid");
                        if (class_is_use_information[class_room_i_id][one_xingqiji][one_time_inter][0]==0)
                        {
                            class_room_fix_one_time[class_room_fix_one_time_num]=String.valueOf(class_room_i_id);
                            class_room_fix_one_time_num++;
                        }
                    }
                }
                if (class_room_fix_one_time_num==0) continue;
                if (fre==3 || fre==2) //一周只上一次课，已找到空余教室即时间，更新表
                {
                    for (String major_ : major)
                    {
                        int major_id_ = major_id.get(major_.substring(2)).intValue();
                        String nianji = major_.substring(0,2);
                        int nianji_id=0;
                        nianji_id=daji_judge(nianji);
                        major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0]=1;
                        for (int week=Integer.parseInt(cstart);week<=Integer.parseInt(cend);week++)
                        {
                            major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][week]=1;
                        }
                    }
                    teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0] = 1;
                    class_is_use_information[Integer.parseInt(class_room_fix_one_time[0])][one_xingqiji][one_time_inter][0] = 1;
//                    System.out.println(one_xingqiji);
                    String new_time1=chinese_sign[one_xingqiji]+","+timeinterToString(one_time_inter,fre/2);
                    ans[13]="0";
                    String new_classroom_id=class_room_fix_one_time[0];
//                            for (int ii=0;ii<14;ii++)
//                                System.out.print(ans[ii]+" ");
//                            System.out.println();
                    String sql="update course set time1='"+new_time1+"',classid='"+new_classroom_id+"' where id="+id;
                    System.out.println(sql);
                    state.executeUpdate(sql);
                    return;

                }
                int two_xingqiji=(one_xingqiji+2)%5;
                int rand_two_time_inter=0;
                while(rand_two_time_inter<=24)
                {
                    int two_time_inter=rand.nextInt(4);
                    if ((fre==3 || fre==6) && two_time_inter==1) continue ;
                    rand_two_time_inter++;
                    for (String major_ : major)
                    {
                        int major_id_ = major_id.get(major_.substring(2)).intValue();
                        String nianji = major_.substring(0,2);
                        int nianji_id=0;
                        nianji_id=daji_judge(nianji);
                        if (major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0]==0) //如果专业有空则继续判断
                        {
                            continue;
                        }
                        else //有专业没空，flag标记跳出
                        {
                            flag_is_busy=false;
                            break;
                        }
                    }
                    if (teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0]==1)
                        flag_is_busy=false;
                    if (flag_is_busy==false)
                    {
                        break;
                    }
                    for (int i=0;i<class_room_fix_one_time.length;i++) //找出所有满足容量里符合时间的教室
                    {
                        int class_room_fix_one_time_int=Integer.parseInt(class_room_fix_one_time[i]);
                        if (class_is_use_information[class_room_fix_one_time_int][two_xingqiji][two_time_inter][0]==0)
                        {
                            for (String major_ : major)
                            {
                                int major_id_ = major_id.get(major_.substring(2)).intValue();
                                String nianji = major_.substring(0,2);
                                int nianji_id=0;
                                nianji_id=daji_judge(nianji);
                                major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0]=1;
                                major_is_busy_information[major_id_][nianji_id][two_xingqiji][two_time_inter][0]=1;
                                for (int week=Integer.parseInt(cstart);week<=Integer.parseInt(cend);week++)
                                {
                                    major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][week]=1;
                                    major_is_busy_information[major_id_][nianji_id][two_xingqiji][two_time_inter][week]=1;

                                }
                            }
                            teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0] = 1;
                            teacher_is_busy_information[tid][two_xingqiji][two_time_inter][0] = 1;
                            for (int week=Integer.parseInt(cstart);week<=Integer.parseInt(cend);week++) {
                                teacher_is_busy_information[tid][one_xingqiji][one_time_inter][week] = 1;
                                class_is_use_information[class_room_fix_one_time_int][one_xingqiji][one_time_inter][week] = 1;
                                teacher_is_busy_information[tid][two_xingqiji][two_time_inter][week] = 1;
                                class_is_use_information[class_room_fix_one_time_int][two_xingqiji][two_time_inter][week] = 1;
                            }
                            String new_time1=chinese_sign[one_xingqiji]+","+timeinterToString(one_time_inter,fre/2);
                            String new_time2=chinese_sign[two_xingqiji]+","+timeinterToString(two_time_inter,fre/2);
                            String new_classroom_id=class_room_fix_one_time[0];
//                            for (int ii=0;ii<14;ii++)
//                                System.out.print(ans[ii]+" ");
//                            System.out.println();
                            String sql="update course set time1='"+new_time1+"',time2='"+new_time2+"',classid='"+new_classroom_id+"' where id="+id;
                            System.out.println(sql);
                            state.executeUpdate(sql);

                            return;
                        }
                    }
                }

                two_xingqiji=(one_xingqiji+3)%5;
                rand_two_time_inter=0;
                while(rand_two_time_inter<=24) {
                    int two_time_inter = rand.nextInt(4);
                    if ((fre == 3 || fre == 6) && one_time_inter == 1) continue;
                    rand_two_time_inter++;
                    for (String major_ : major) {
                        int major_id_ = major_id.get(major_.substring(2)).intValue();
                        String nianji = major_.substring(0, 2);
                        int nianji_id = 0;
                        nianji_id = daji_judge(nianji);
                        if (major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0] == 0) //如果专业有空则继续判断
                        {
                            continue;
                        } else //有专业没空，flag标记跳出
                        {
                            flag_is_busy = false;
                            break;
                        }
                    }
                    if (teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0] == 1)
                        flag_is_busy = false;
                    if (flag_is_busy == false) {
                        break;
                    }
                    for (int i = 0; i < class_room_fix_one_time.length; i++) //找出所有满足容量里符合时间的教室
                    {
                        int class_room_fix_one_time_int = Integer.parseInt(class_room_fix_one_time[i]);
                        if (class_is_use_information[class_room_fix_one_time_int][two_xingqiji][two_time_inter][0] == 0) {
                            for (String major_ : major) {
                                int major_id_ = major_id.get(major_.substring(2)).intValue();
                                String nianji = major_.substring(0, 2);
                                int nianji_id = 0;
                                nianji_id = daji_judge(nianji);
                                major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0] = 1;
                                major_is_busy_information[major_id_][nianji_id][two_xingqiji][two_time_inter][0] = 1;
                                for (int week = Integer.parseInt(cstart); week <= Integer.parseInt(cend); week++) {
                                    major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][week] = 1;
                                    major_is_busy_information[major_id_][nianji_id][two_xingqiji][two_time_inter][week] = 1;

                                }
                            }
                            teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0] = 1;
                            teacher_is_busy_information[tid][two_xingqiji][two_time_inter][0] = 1;
                            for (int week = Integer.parseInt(cstart); week <= Integer.parseInt(cend); week++) {
                                teacher_is_busy_information[tid][one_xingqiji][one_time_inter][week] = 1;
                                class_is_use_information[class_room_fix_one_time_int][one_xingqiji][one_time_inter][week] = 1;
                                teacher_is_busy_information[tid][two_xingqiji][two_time_inter][week] = 1;
                                class_is_use_information[class_room_fix_one_time_int][two_xingqiji][two_time_inter][week] = 1;
                            }
                            String new_time1=chinese_sign[one_xingqiji]+","+timeinterToString(one_time_inter,fre/2);
                            String new_time2=chinese_sign[two_xingqiji]+","+timeinterToString(two_time_inter,fre/2);
                            String new_classroom_id=class_room_fix_one_time[0];
//                            for (int ii=0;ii<14;ii++)
//                                System.out.print(ans[ii]+" ");
//                            System.out.println();
                            String sql="update course set time1="+new_time1+",time2="+new_time2+",classid="+new_classroom_id+" where id="+id;
                            System.out.println(sql);
                            state.executeUpdate(sql);
                            return;
                        }
                    }
                }
            }

        }
    }

    //      处理major_id
    public void init_major_id() throws SQLException {
        String sql_college_major="select * from collegemajor";
        ResultSet college_major = state.executeQuery(sql_college_major);
        String tmp=new String();
        while (college_major.next()) {
            String major_name = college_major.getString("majorname");
            major_id.put(major_name, major_num);
            System.out.println(major_name+major_id.get(major_name));
            tmp=major_name;
            major_num++;
        }
//        major_id.get(tmp) 对应major的序号id
    }
    //     预处理需要上课周数及上课频率

    //一下为获取教室所有信息模块
    void check_class() throws Exception
    {
        String sql_classroom="select * from classroom";                //取出教室的所有信息
        ResultSet class_room= state.executeQuery(sql_classroom);        //执行SQL语句

        while(class_room.next())        //获取教室信息  这里不要动
        {
            String  id = class_room.getString("classid");
            String  name = class_room.getString("classname");
            String  capacity = class_room.getString("classvol");
            String temp[] = new String[3];
            temp[0]=id;
            temp[1]=name;
            temp[2]=capacity;
            class_room_information[class_room_num]=temp;
            class_room_num++;
        }
        //结束
    }
    //打印模块 用于输出数据库二维数组
    void Print(String temp[][])
    {
        for(int i=0;i<temp.length;i++)
        {
            for(int j=0;j<temp[i].length;j++)
            {
                System.out.print(temp[i][j]+" ");
            }
            System.out.println();
        }

    }
    public void read_txt() throws Exception
    {
        FileReader in1 = new FileReader("./class_is_use_information.txt");
        FileReader in2 = new FileReader("./teacher_is_busy_information.txt");

        for (int i = 0; i < 1000; i++)
            for (int j = 0; j < 7; j++)
                for (int z = 0; z < 4; z++)
                    for (int t = 0; t < 100; t++) {
                        int tt1 = 0, tt2 = 0;
                        try {
                            tt1 = in1.read() - 48;
                            tt2 = in2.read() - 48;

                        } catch (IOException e1) {
                            e1.printStackTrace();
                        }
                        class_is_use_information[i][j][z][t] = tt1;
                        teacher_is_busy_information[i][j][z][t] = tt2;
                    }
        FileReader in3 = new FileReader("./major_is_busy_information.txt");
        for (int i = 0; i < 1000; i++)
            for (int p = 0; p < 4; p++)
                for (int j = 0; j < 7; j++)
                    for (int z = 0; z < 4; z++)
                        for (int t = 0; t < 100; t++) {
                            int tt = 0;
                            try {
                                tt = in3.read() - 48;
                            } catch (IOException e1) {
                                e1.printStackTrace();
                            }
                            major_is_busy_information[i][p][j][z][t] = tt;
                        }
    }
    public void sdpk_choose(String id) throws Exception {
        String sql="select * from course where id="+id;
        String data[] = new String[20];
        ResultSet res=state.executeQuery(sql);
        String time1 ="",time2="",cmajor="",tid="",call="",cstart="",cend="";
        while(res.next())
        {
            time1= res.getString("time1");
            time2= res.getString("time2");
            cmajor= res.getString("cmajor");
            tid= res.getString("tid");
            call= res.getString("call");
            cstart=res.getString("cstart");
            cend=res.getString("cend");
            break;
        }
        int fre;
        if (time1.split(",").length == 4) fre = 3;
        else fre = 2;
        //  System.out.println(time2);
        if (time2.equals("")) {}
        else fre *= 2;
        System.out.println("fre"+fre);
        random_course(id+"",time1,time2,cmajor,tid,call,cstart,cend,fre);
    }
    Main(String id) throws Exception
    {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/1603_?useUnicode=true&characterEncoding=UTF-8&useSSL=true", "root", "zhouzhou");
        state = conn.createStatement();
        init_major_id();
        read_txt();

        check_class();
        sdpk_choose(id);
        save_txt();

    }
}

