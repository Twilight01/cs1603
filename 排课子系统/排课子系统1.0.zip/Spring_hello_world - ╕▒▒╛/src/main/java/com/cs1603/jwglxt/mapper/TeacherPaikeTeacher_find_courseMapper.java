package com.cs1603.jwglxt.mapper;
import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import com.cs1603.jwglxt.bean.paike.Result;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface TeacherPaikeTeacher_find_courseMapper {
    @Select("select * from coursehistory where year=#{year} and semester=#{semester} and tid=#{tid} ")
    public Coursehistory[] tearch_find(@Param("year") String year, @Param("semester") Integer  semester, @Param("tid") String tid);
}
