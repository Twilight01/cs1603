package com.cs1603.jwglxt.mapper;
import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_for_chaxun;
import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_tid_for_change;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface AdminPaikeSdpk_tidMapper {
   // @Select("select * from course ")
 // @Select("select course.tid,teacher.tname,cname,time1,time2,classname,cmajor from course,teacher,classroom where course.tid = teacher.tid and course.classid=classroom.classid and course.tid=#{tid}")
    @Select("select course.id,teacher.tid,tname,cname,time1,time2,classroom.classname,cmajor  from course,teacher,classroom where teacher.tid = course.tid and course.classid=classroom.classid and teacher.tid=#{tid}")
    public Course_for_qianduan_tid_for_change[] findall(@Param("tid") String tid);

}


