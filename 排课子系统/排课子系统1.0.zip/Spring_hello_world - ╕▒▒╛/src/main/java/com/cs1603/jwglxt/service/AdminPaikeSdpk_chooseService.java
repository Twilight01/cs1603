package com.cs1603.jwglxt.service;

import com.cs1603.jwglxt.bean.paike.*;
import com.cs1603.jwglxt.mapper.AdminPaikeSdpk_chooseMapper;
import com.cs1603.jwglxt.result.ResultUtil;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;

@Service
public class AdminPaikeSdpk_chooseService {
    @Resource
    private AdminPaikeSdpk_chooseMapper adminPaikeSdpk_chooseMapper;
    public Course_for_qianduan_tid_for_change[] new_course_after_chongxinpaike(String id)
    {
        return adminPaikeSdpk_chooseMapper.findall(id);
    }
}
