package com.cs1603.jwglxt.controller;
import com.cs1603.jwglxt.bean.paike.*;
import com.cs1603.jwglxt.service.TeacherPaikeTeacher_find_courseService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
/**
 * 老师查询老师课表：
 *url：api/teacher/teacher_find_course
 * 参数：year(String),semester(String),tid(String)
 * 返回：json该专业当前学年学期课表（String[][]）
 * */
@Controller
public class TeacherPaikeTeacher_find_courseController {

    @Resource
    private TeacherPaikeTeacher_find_courseService teacherPaikeTeacherfindcourseService;
    @CrossOrigin
    @ResponseBody
    @RequestMapping("api/teacher/teacher_find_course")
    public Result<Coursehistory> login(@RequestBody Coursehistory requestUser) {
        String Year = requestUser.getYear();
        Integer semester = requestUser.getSemester();
        System.out.println(semester);
        String tid = requestUser.getTid();
        System.out.println("teacher"+Year);
       return teacherPaikeTeacherfindcourseService.tearch_find(Year,semester,tid);
    }
}
