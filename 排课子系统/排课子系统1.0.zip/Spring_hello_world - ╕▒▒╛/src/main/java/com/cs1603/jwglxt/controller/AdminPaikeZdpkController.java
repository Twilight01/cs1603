package com.cs1603.jwglxt.controller;


import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Course_zdpk;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import com.cs1603.jwglxt.bean.paike.Flag;
import com.cs1603.jwglxt.service.AdminPaikeZdpkService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import javax.annotation.Resource;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.sql.*;

@Controller
public class AdminPaikeZdpkController {
    @Resource
    private AdminPaikeZdpkService adminPaikeZdpkService;
    @CrossOrigin
    @ResponseBody
    @RequestMapping("/api/admin/zdpk")
    public String zdpk() throws Exception
    {

        zdpk zdpk_ = new zdpk();
        return "Success";
//        if(flag_.equals("0"))
//        {
//            if(adminPaikeZdpkService.is_alreay_paike_().length!=0)
//            {
//                return "Success";
//            }
//            else
//            {
//                return "true";
//            }
//        }
//        else
//        {
//
//            zdpk zdpk_ = new zdpk();
//            //System.out.println(test);
//            return "Success";
//        }


    }
}
class zdpk
{
    String year_="2016";
    int semester=1;
    Random rand = new Random();
    int [][][][] class_is_use_information = new int[1000][7][4][100];   // [阶教101[大一][周一][第一个时间段][第15周]
    int [][][][][] major_is_busy_information = new int[1000][4][7][4][100]; // [计科][大一][周一][第一个时间段][第15周]
    int [][][][] teacher_is_busy_information = new int[1000][7][4][100];    // [tid][大一][周一][第一个时间段][第15周]
    int [] course_id_is_use = new int [1000];
    //        major_id.get(tmp) 对应major的序号id
    Map<String, Integer> major_id = new HashMap<String, Integer>();
    int major_num=0; // 所有专业数

    String[][] class_room_information = new String[1000][3];     //二维数组 存放着教室信息
    //[0]{1,A阶101，180      }
    //[1]{2,A阶102，180     }
    char[] chinese_sign = new char[]{'一','二','三','四','五','六','七'};
    int class_room_num =0;  //记录教室数量
    Connection conn ;
    Statement state;
    //从数据库提取信息，每次读出二维String
    void save_txt() throws IOException {
        File file1 = new File("./class_is_use_information.txt");
        File file2 = new File("./major_is_busy_information.txt");
        File file3 = new File("./teacher_is_busy_information.txt");
        FileWriter out1 = new FileWriter(file1);
        FileWriter out2 = new FileWriter(file2);
        FileWriter out3 = new FileWriter(file3);
        for(int i=0;i<1000;i++)
            for(int j=0;j<7;j++)
                for(int z=0;z<4;z++)
                    for(int t=0;t<100;t++) {
                        out1.write(class_is_use_information[i][j][z][t] + "");

                        out3.write( teacher_is_busy_information[i][j][z][t]+"");
                    }
        for(int i=0;i<1000;i++)
            for(int p=0;p<4;p++)
            for(int j=0;j<7;j++)
                for(int z=0;z<4;z++)
                    for(int t=0;t<100;t++) {
                        out2.write( major_is_busy_information[i][p][j][z][t]+"");
                    }




        out1.close();
        out2.close();
        out3.close();

    }
    public String[][] get_sql_information_to_array(String sql) throws Exception
    {
        ResultSet sql_handle=state.executeQuery(sql);
        sql_handle.last();
        int hangshu = sql_handle.getRow();
//        System.out.println("行数"+hangshu);
        sql_handle.beforeFirst();
        ResultSetMetaData sql_handle_data = sql_handle.getMetaData();
        int columncount = sql_handle_data.getColumnCount();
        String temp[][] = new String[hangshu][columncount];
        int hang = 0;
        while(sql_handle.next())
        {
            String temp_hang[]=new String[columncount];
            for(int i=0;i<columncount;i++)
            {
                temp_hang[i] = sql_handle.getString(i+1);
//                System.out.println(temp_hang[i]);
            }
            temp[hang] = temp_hang;
            hang++;
        }
        return temp;
    }
    public String[] class_room_fix_your_need(  int  rongliang  ) throws Exception
    {
        String sql = "select classid from classroom where classvol <="+rongliang;
//        System.out.println(sql);
        String temp[][]=new String [50][50];
        temp=get_sql_information_to_array(sql);
        String res[] = new String [temp.length];
        for(int i=0;i<temp.length;i++)
        {
            res[i]=temp[i][0];
        }
        return res;
    }
    int daji_judge(String nianji)
    {
        int nianji_id=0;
        if (nianji.equals("大一"))  nianji_id=0;
        if (nianji.equals("大二"))  nianji_id=1;
        if (nianji.equals("大三"))  nianji_id=2;
        if (nianji.equals("大四"))  nianji_id=3;
        return nianji_id;
    }
    String timeinterToString(int t, int jie)
    {
        String ans="";
        if (jie==2)
        {
            if (t==0) ans="1,2";
            if (t==1) ans="4,5";
            if (t==2) ans="7,8";
            if (t==3) ans="11,12";
        }
        else
        {
            if (t==0) ans="1,2,3";
            if (t==1) ans="4,5";
            if (t==2) ans="7,8,9";
            if (t==3) ans="11,12,13";
        }

        return ans;
    }
    public String[] erwei_to_yiwei(String temp[][])
    {
        String res[] = new String [temp.length];
        for(int i=0;i<temp.length;i++)
        {
            res[i] = temp[i][0];
        }
        return res;
    }
    //通过String数组录入sql语句对数据库进行添加
    public void change_sql(String temp[]) throws Exception
    {
        String sql_change="";
        for(int temp_i = 1;temp_i <=12;temp_i++)
        {
            sql_change = sql_change+"'"+temp[temp_i]+"',";
        }
        sql_change = sql_change+"'"+temp[13]+"'";
        String insert_sql="INSERT INTO `1603_`.`course`(`cnum`, `cname`, `cmajor`, `ctype`, `tid`, `call`, `cstart`, `cend`, `credit`, `time1`, `time2`, `classid`, `cnow`) VALUES ( "+sql_change+")";
        state.executeUpdate(insert_sql);
    }
    //   排专业1的课表，对于每一门课调用random_course
    public void random_course(String[] tmp) throws Exception
    {
//          id：对应coursesorting的id课程序号
//          fre：上课频率
//          majors：需要上该课的所有专业
//          tid：教师编号
//          vol：该课程容量
//          先随机星期几，再随机时间段
//          根据课程容量，随机教室
//          fre=6 即3*2;fre=4 即2*2;fre=3 即3*1;fre=2 即2*1
//        for (String tmp_:tmp)
//        {
//            System.out.print(tmp_+" ");
//        }
//        System.out.println();
        String [] ans=new String[100];
        int ans_l=tmp.length;
        for (int i=0;i<tmp.length;i++)
            ans[i]=tmp[i];
        int id=Integer.parseInt(tmp[0]);
        if (course_id_is_use[id]!=0) return;
        course_id_is_use[id]=1;
        int fre=Integer.parseInt(tmp[11]);
        String majors=tmp[3];
        int tid=Integer.parseInt(tmp[5]);
        int vol=Integer.parseInt(tmp[6]);
        int start_week=Integer.parseInt(tmp[7]);
        int end_week=Integer.parseInt(tmp[8]);
        String class_room_fix_need[] = new String[1000]; //符合容量的教室编号
        String class_room_fix_one_time[] = new String[1000]; //符合第一次时间的教室编号
        int class_room_fix_one_time_num=0;

        class_room_fix_need = class_room_fix_your_need(vol);
        int rand_one_xingqiji=0;
        String[] major = majors.split("，");
        firstRandXingqiji:
        while (rand_one_xingqiji<=120) //随机次数
        {

            int one_xingqiji=rand.nextInt(5);
            int rand_one_time_inter=0;
            rand_one_xingqiji++;
            firstRandTime:
            while(rand_one_time_inter<=24)
            {
                int one_time_inter=rand.nextInt(4);
                if ((fre==3 || fre==6) && one_time_inter==1) continue ;
                boolean flag_is_busy=true;
                rand_one_time_inter++;
                for (String major_ : major) //查专业是否有空
                {
//                    System.out.println(123+ major_id.get(major_));
//                    System.out.println("专业？："+major_.substring(2));
                    int major_id_ = major_id.get(major_.substring(2)).intValue();
//                    System.out.println(major_id_);
                    String nianji = major_.substring(0,2);
                    int nianji_id=0;
                    nianji_id=daji_judge(nianji);


                    //大二化学专业 从第二个开始截取 即为化学专业
                    if (major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0]==0) //如果专业有空则继续判断
                    {
                        continue;
                    }
                    else //有专业没空，flag标记跳出
                    {
                        flag_is_busy=false;
                        break;
                    }
                }
                if (teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0]==1) {
                    flag_is_busy=false;
                }
                if (flag_is_busy==false)
                {
                    break;
                }
//以上无错
                for (int i=0;i<class_room_fix_need.length;i++) //找出所有满足容量里符合时间的教室
                {
                    int class_room_i_id;
                    String sql_class_room_id="select classid from classroom where classid="+class_room_fix_need[i];
                    ResultSet class_room_ids=state.executeQuery(sql_class_room_id);
                    while (class_room_ids.next())
                    {
                        class_room_i_id=class_room_ids.getInt("classid");
                        if (class_is_use_information[class_room_i_id][one_xingqiji][one_time_inter][0]==0)
                        {
                            class_room_fix_one_time[class_room_fix_one_time_num]=String.valueOf(class_room_i_id);
                            class_room_fix_one_time_num++;
                        }
                    }
                }
                if (class_room_fix_one_time_num==0) continue;
                if (fre==3 || fre==2) //一周只上一次课，已找到空余教室即时间，更新表
                {
                    for (String major_ : major)
                    {
                        int major_id_ = major_id.get(major_.substring(2)).intValue();
                        String nianji = major_.substring(0,2);
                        int nianji_id=0;
                        nianji_id=daji_judge(nianji);
                        major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0]=1;
                        for (int week=start_week;week<=end_week;week++)
                        {
                            major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][week]=1;
                        }
                    }
                    teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0] = 1;
                    class_is_use_information[Integer.parseInt(class_room_fix_one_time[0])][one_xingqiji][one_time_inter][0] = 1;
//                    System.out.println(one_xingqiji);
                    ans[10]=chinese_sign[one_xingqiji]+","+timeinterToString(one_time_inter,fre);
                    ans[11]="";
                    ans[13]="0";
                    ans[12]=class_room_fix_one_time[0];
                    change_sql(ans);
                    return;

                }
                int two_xingqiji=(one_xingqiji+2)%5;
                int rand_two_time_inter=0;
                while(rand_two_time_inter<=24)
                {
                    int two_time_inter=rand.nextInt(4);
                    if ((fre==3 || fre==6) && two_time_inter==1) continue ;
                    rand_two_time_inter++;
                    for (String major_ : major)
                    {
                        int major_id_ = major_id.get(major_.substring(2)).intValue();
                        String nianji = major_.substring(0,2);
                        int nianji_id=0;
                        nianji_id=daji_judge(nianji);
                        if (major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0]==0) //如果专业有空则继续判断
                        {
                            continue;
                        }
                        else //有专业没空，flag标记跳出
                        {
                            flag_is_busy=false;
                            break;
                        }
                    }
                    if (teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0]==1)
                        flag_is_busy=false;
                    if (flag_is_busy==false)
                    {
                        break;
                    }
                    for (int i=0;i<class_room_fix_one_time.length;i++) //找出所有满足容量里符合时间的教室
                    {
                        int class_room_fix_one_time_int=Integer.parseInt(class_room_fix_one_time[i]);
                        if (class_is_use_information[class_room_fix_one_time_int][two_xingqiji][two_time_inter][0]==0)
                        {
                            for (String major_ : major)
                            {
                                int major_id_ = major_id.get(major_.substring(2)).intValue();
                                String nianji = major_.substring(0,2);
                                int nianji_id=0;
                                nianji_id=daji_judge(nianji);
                                major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0]=1;
                                major_is_busy_information[major_id_][nianji_id][two_xingqiji][two_time_inter][0]=1;
                                for (int week=start_week;week<=end_week;week++)
                                {
                                    major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][week]=1;
                                    major_is_busy_information[major_id_][nianji_id][two_xingqiji][two_time_inter][week]=1;

                                }
                            }
                            teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0] = 1;
                            teacher_is_busy_information[tid][two_xingqiji][two_time_inter][0] = 1;
                            for (int week=start_week;week<=end_week;week++) {
                                teacher_is_busy_information[tid][one_xingqiji][one_time_inter][week] = 1;
                                class_is_use_information[class_room_fix_one_time_int][one_xingqiji][one_time_inter][week] = 1;
                                teacher_is_busy_information[tid][two_xingqiji][two_time_inter][week] = 1;
                                class_is_use_information[class_room_fix_one_time_int][two_xingqiji][two_time_inter][week] = 1;
                            }
                            ans[10]=chinese_sign[one_xingqiji]+","+timeinterToString(one_time_inter,fre/2);
                            ans[11]=chinese_sign[two_xingqiji]+","+timeinterToString(two_time_inter,fre/2);
                            ans[13]="0";
                            ans[12]=class_room_fix_one_time[0];
//                            for (int ii=0;ii<14;ii++)
//                                System.out.print(ans[ii]+" ");
//                            System.out.println();
                            change_sql(ans);

                            return;
                        }
                    }
                }

                two_xingqiji=(one_xingqiji+3)%5;
                rand_two_time_inter=0;
                while(rand_two_time_inter<=24) {
                    int two_time_inter = rand.nextInt(4);
                    if ((fre == 3 || fre == 6) && one_time_inter == 1) continue;
                    rand_two_time_inter++;
                    for (String major_ : major) {
                        int major_id_ = major_id.get(major_.substring(2)).intValue();
                        String nianji = major_.substring(0, 2);
                        int nianji_id = 0;
                        nianji_id = daji_judge(nianji);
                        if (major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0] == 0) //如果专业有空则继续判断
                        {
                            continue;
                        } else //有专业没空，flag标记跳出
                        {
                            flag_is_busy = false;
                            break;
                        }
                    }
                    if (teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0] == 1)
                        flag_is_busy = false;
                    if (flag_is_busy == false) {
                        break;
                    }
                    for (int i = 0; i < class_room_fix_one_time.length; i++) //找出所有满足容量里符合时间的教室
                    {
                        int class_room_fix_one_time_int = Integer.parseInt(class_room_fix_one_time[i]);
                        if (class_is_use_information[class_room_fix_one_time_int][two_xingqiji][two_time_inter][0] == 0) {
                            for (String major_ : major) {
                                int major_id_ = major_id.get(major_.substring(2)).intValue();
                                String nianji = major_.substring(0, 2);
                                int nianji_id = 0;
                                nianji_id = daji_judge(nianji);
                                major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][0] = 1;
                                major_is_busy_information[major_id_][nianji_id][two_xingqiji][two_time_inter][0] = 1;
                                for (int week = start_week; week <= end_week; week++) {
                                    major_is_busy_information[major_id_][nianji_id][one_xingqiji][one_time_inter][week] = 1;
                                    major_is_busy_information[major_id_][nianji_id][two_xingqiji][two_time_inter][week] = 1;

                                }
                            }
                            teacher_is_busy_information[tid][one_xingqiji][one_time_inter][0] = 1;
                            teacher_is_busy_information[tid][two_xingqiji][two_time_inter][0] = 1;
                            for (int week = start_week; week <= end_week; week++) {
                                teacher_is_busy_information[tid][one_xingqiji][one_time_inter][week] = 1;
                                class_is_use_information[class_room_fix_one_time_int][one_xingqiji][one_time_inter][week] = 1;
                                teacher_is_busy_information[tid][two_xingqiji][two_time_inter][week] = 1;
                                class_is_use_information[class_room_fix_one_time_int][two_xingqiji][two_time_inter][week] = 1;
                            }
                            ans[10] = chinese_sign[one_xingqiji] + "," + timeinterToString(one_time_inter,fre/2);
                            ans[11] = chinese_sign[two_xingqiji] + "," + timeinterToString(two_time_inter,fre/2);
                            ans[13] = "0";
                            ans[12] = class_room_fix_one_time[0];
//                            for (int ii = 0; ii < 14; ii++)
//                                System.out.print(ans[ii] + " ");
//                            System.out.println();
                            change_sql(ans);

                            return;
                        }
                    }
                }
            }

        }
    }

    //      处理major_id
    public void init_major_id() throws Exception {
        String sql_college_major="select * from collegemajor";
        ResultSet college_major = state.executeQuery(sql_college_major);
        String tmp=new String();
        while (college_major.next()) {
            String major_name = college_major.getString("majorname");
            major_id.put(major_name, major_num);
//            System.out.println(major_name+major_id.get(major_name));
            tmp=major_name;
            major_num++;
        }
//        major_id.get(tmp) 对应major的序号id
    }
    //     预处理需要上课周数及上课频率
    public void init() throws Exception
    {

        String sql_course="select * from coursesorting";
        ResultSet course=state.executeQuery(sql_course);
        String[][] course_information = new String[1000][1000];
        String[][] updata_sql = new String [1000][5];

        int course_num=0;
        while (course.next())
        {
            String id=course.getString("id");
            String ctime=course.getString("ctime");
            String ctype=course.getString("ctype");

            int ctime_int=Integer.parseInt(ctime);
            int start_week=1,end_week=0,fre;
            if (ctype.equals("通识") || ctype.equals("专业选修"))
            {
                start_week=3;
            }
            if (ctime_int>=96) // 16*3*2
            {
                end_week = start_week+ctime_int/6;
                fre=6;
            }
            else if (ctime_int>=72) // 18*2*2
            {
                end_week = start_week+ctime_int/4;
                fre=4;
            }
            else if (ctime_int>=64) // 16*2*2
            {
                end_week = start_week+ctime_int/4;
                fre=4;
            }
            else if (ctime_int>=54) // 9*3*2
            {
                end_week = start_week+ctime_int/6;
                fre=6;
            }
            else if (ctime_int>=48) //16*3
            {
                end_week = start_week+ctime_int/3;
                fre=3;
            }
            else if (ctime_int>=36) // 12*3
            {
                end_week = start_week+ctime_int/3;
                fre=3;
            }
            else if (ctime_int>=24) //8*3
            {
                end_week = start_week+ctime_int/3;
                fre=3;
            }
            else // 小于等于12 6*2
            {
                end_week = start_week+ctime_int/2;
                fre=2;
            }
            String sql_change="'"+String.valueOf(start_week)+"','"+String.valueOf(end_week)+"','"+String.valueOf(fre)+"'";
            String start_week_string = String.valueOf(start_week);
            String end_week_string = String.valueOf(end_week);
            String id_string = String.valueOf(id);

            String fre_string = String.valueOf(fre);

            updata_sql[course_num][0]="UPDATE `1603_`.`coursesorting` SET cstart='"+start_week_string+ "' WHERE id="+id_string+";";
            updata_sql[course_num][1]="UPDATE `1603_`.`coursesorting` SET cend='"+end_week_string+ "' WHERE id="+id_string+";";
            updata_sql[course_num][2]="UPDATE `1603_`.`coursesorting` SET cfre='"+fre_string+ "' WHERE id="+id_string+";";
            course_num++;
        }
        for (int i=0;i<course_num;i++)
        {
            for (int j=0;j<3;j++)
            {
//                System.out.println(updata_sql[i][j]);
                state.executeUpdate(updata_sql[i][j]);

            }
        }
    }

    void other_course() throws Exception
    {
        String sql_other="select * from coursesorting where ctype='公共基础必修' or ctype='专业选修' or ctype='专业必修'";
        String [][] course_other_information = new String[1000][1000];

        course_other_information = get_sql_information_to_array(sql_other);
        int course_num=course_other_information.length;
        for (String major_tmp : major_id.keySet()) // 对于每一专业去排课
        {
            for (int daji=0;daji<4;daji++)
            {
                String sql_major_class = "select * from coursesorting where (ctype='公共基础必修' or ctype='专业选修' or ctype='专业必修') and cmajor like '%大"+chinese_sign[daji]+major_tmp+"%'";
                String [][] tmp = get_sql_information_to_array(sql_major_class);
                for (int e_class=0;e_class<tmp.length;e_class++)
                {
                    random_course(tmp[e_class]);
                }
            }

        }

    }

    //一下为获取教室所有信息模块
    void check_class() throws Exception
    {
        String sql_classroom="select * from classroom";                //取出教室的所有信息
        ResultSet class_room= state.executeQuery(sql_classroom);        //执行SQL语句

        while(class_room.next())        //获取教室信息  这里不要动
        {
            String  id = class_room.getString("classid");
            String  name = class_room.getString("classname");
            String  capacity = class_room.getString("classvol");
            String temp[] = new String[3];
            temp[0]=id;
            temp[1]=name;
            temp[2]=capacity;
            class_room_information[class_room_num]=temp;
            class_room_num++;
        }
        //结束
    }

    //体育
    void tiyu() throws Exception
    {
        String temp[][] = new String[50][50];
        temp = get_sql_information_to_array("select  distinct collegeName from collegemajor");
        String yuan[] = new String[temp.length];
        for (int i = 0; i < temp.length; i++) {
            yuan[i] = temp[i][0];
        }
//            String now_to_paike_yuan = yuan[i];     //获取需要排课的院系
        String sql = "select * from coursesorting where cmajor = '全部专业' and ctype = '体育'";
        String temp_1[][] = new String[100][100];
        temp_1 = get_sql_information_to_array(sql);
        String ke[] = new String[14];
        //  [0][ 43 T031 网页与网站设计 全部专业 通识教育课程 3 180 1 9 2.0 24 3     ]
        int tid = Integer.parseInt(temp_1[0][5]);
        for (int daji = 0; daji < 2; daji++)
        {
            for (String i : yuan)          //获取每个院的名字   信息学院
            {
                while (true) {
                    int xingqi = rand.nextInt(5);       //随机星期几 1-5
                    int shijianduan = rand.nextInt(2) + 1;    //随机时间段 2或者3
                    if (teacher_is_busy_information[tid][xingqi][shijianduan][0] == 0) {

                        sql = "select majorName from collegemajor where collegeName = '" + i + "'"; //提取这个院的所有专业信息
                        String zhuanye_information[] = new String[100];         //这个一维数组 记录的是专业信息
                        zhuanye_information = erwei_to_yiwei(get_sql_information_to_array(sql));
                        for (String zhuanye_mingzi : zhuanye_information) {
                            int zhuanye_id = major_id.get(zhuanye_mingzi);  //对应major的序号id
                            for (int ke_i = 0; ke_i < temp_1.length; ke_i++)      //每一门体育课 现在是第一门 篮球
                            {
                                for (int tt = 0; tt < temp_1[ke_i].length; tt++) {
                                    ke[tt] = temp_1[ke_i][tt];
                                }

                                teacher_is_busy_information[tid][xingqi][shijianduan][0] = 1;     //这个老师再这个时间段繁忙
                                major_is_busy_information[zhuanye_id][daji][xingqi][shijianduan][0] = 1;      //这个专业 包括大几 再这个时间段繁忙
                                ke[3] = "大" + chinese_sign[daji] + zhuanye_mingzi;
                                if (shijianduan==1)
                                {
                                    ke[10] = chinese_sign[xingqi] + "," + timeinterToString(shijianduan,2);
                                }
                                else
                                {
                                    ke[10] = chinese_sign[xingqi] + ",7,8" ;
                                }
                                ke[11] = "";
                                ke[12] = "0";
                                ke[13]="体育馆";
                                change_sql(ke);
                            }
                            // System.out.println("专业名字"+zhuanye_mingzi+"专业id"+zhuanye_id);
                        }
                        break;
                    }

                }
            }
        }
    }

    //以下为获取+对通识课信息
    void tongshi() throws Exception
    {
        String sql_tongshi="select * from coursesorting where ctype='通识教育课程'";       //取出通识课的所以信息
        ResultSet course_tongshi= state.executeQuery(sql_tongshi);
        ResultSetMetaData course_tongshi_data = course_tongshi.getMetaData();
        int columncount = course_tongshi_data.getColumnCount();     //通识课的字段数
        String [][] couser_tongshi_information = new String[1000][1000];
        //[0][5, T001, 电影欣赏, 全校学生, 通识, 老师E, 180, null,null， 1,64, null]
        //[1][8, T002, NBA鉴赏, 全校学生, 通识, 老师NBA, 180, null,null,1,64,  null]
        int tongshi_num=0;
        while(course_tongshi.next())
        {
            String temp_value;
            String []temp = new String[1000];
            for(int i=0;i<columncount;i++)
            {
                temp_value = course_tongshi.getString(i+1);            //.getString(i) 把每个字段的值取出来
                temp[i]=temp_value;
            }
            couser_tongshi_information[tongshi_num]=temp;
            tongshi_num++;
        }
        //获取结束
        for(int i=0;i<tongshi_num;i++)
        {
            while(true)
            {
                int xingqiji = rand.nextInt(5); //随机星期几 1-5
                String class_room_to_tongshi[] =    class_room_fix_your_need(Integer.parseInt(couser_tongshi_information[i][6])-30 );
                int temp_class = rand.nextInt(class_room_to_tongshi.length);           //随机教室
                int jiaoshi = Integer.parseInt(class_room_to_tongshi[temp_class]);
                if(    class_is_use_information[jiaoshi][xingqiji][3][0]==0)
                {
                    class_is_use_information[jiaoshi][xingqiji][3][0]=1;
                    int cstart = Integer.parseInt(couser_tongshi_information[i][7]);    //开始周数
                    int cend = Integer.parseInt(couser_tongshi_information[i][8]);  //结束周数
                    int tid = Integer.parseInt(couser_tongshi_information[i][5]);   //老师编号
                    for(int j=cstart;j<=cend;j++)
                    {
                        class_is_use_information[jiaoshi][xingqiji][3][j]=1;            //刷新教室使用信息
                        teacher_is_busy_information[tid][xingqiji][3][j]=1;             //刷新老师繁忙信息
                    }
                    couser_tongshi_information[i][10]= chinese_sign[xingqiji]+","+"11,12,13";
                    couser_tongshi_information[i][11] = "";
                    couser_tongshi_information[i][12] = (class_room_information[jiaoshi][0]);
                    couser_tongshi_information[i][13] = "0";
                    change_sql(couser_tongshi_information[i]);
                    break;
                }
            }
        }
    }

    void shixi() throws Exception
    {
        String sql_shixi="select * from coursesorting where ctype='实践环节必修'";       //取出实习课的所有
        ResultSet course_shixi =  state.executeQuery(sql_shixi);
        ResultSetMetaData course_shixi_data = course_shixi.getMetaData();
        int columncount   = course_shixi_data.getColumnCount();
        String[][] courser_shixi_information = new String [100][100];
        int shixi_num=0;
        while(course_shixi.next())
        {
            String temp_value;
            String[] temp = new String[50];
            for(int i=0;i<columncount;i++)
            {
                temp_value = course_shixi.getString(i+1);            //.getString(i) 把每个字段的值取出来
                temp[i]=temp_value;

            }
            courser_shixi_information[shixi_num]=temp;
            shixi_num++;
        }
//        System.out.println(shixi_num);
//        //获取结束
//        for(int i=0;i<shixi_num;i++)
//        {
//            for(int j=0;j<columncount;j++)
//            {
//                System.out.print(courser_shixi_information[i][j]+" ");
//            }
//            System.out.println();
//        }
        int tag1 = 0,tag2 = 0;
        for(int i =0;i < class_room_num;i++)
        {
            if(class_room_information[i][1].equals("实验楼E101"))
            {
                tag1=i;
            }
            if(class_room_information[i][1].equals("实验楼E609"))
            {
                tag2=i;
//                break;
            }

        }
        for(int i =0;i < shixi_num;i++)
        {
            //持续六周时间 整个学年分为三个时间段
            //只在周末上 所以把周末上下午分为四个时间段
            int flag=tag2-tag1;
            int duan1 = rand.nextInt(3);//随机学年的那个时间段 1-6周 ，7-12周，13-18周
            int duan2 = rand.nextInt(4);//随机周末的时间段
            int jiaoshi = rand.nextInt(flag);//随机金工实习车间
            int cstar=duan1*6+1;
            int cend= cstar+5;
            int tid=Integer.parseInt(courser_shixi_information[i][5]);
            for(int j=cstar;j<=cend;j++) //时间段
            {
                if((class_is_use_information[jiaoshi+tag1][duan2/2+5][duan2%2][j]==1)
                        ||( teacher_is_busy_information[tid][duan2/2+5][duan2%2][j])==1)//只判断教室是否冲突
                {
                    j--;
                    break;
                }
                else
                {
                    class_is_use_information[jiaoshi+flag][duan2/2+5][duan2%2][j]=1;

                    teacher_is_busy_information[tid][duan2/2+5][duan2%2][j]=1;

                }
            }
            if(duan2%2==0)
            {
                courser_shixi_information[i][10]=chinese_sign[duan2/2+5]+","+"1,2,3,4";
            }
            else
            {
                courser_shixi_information[i][10]=chinese_sign[duan2/2+5]+","+"6,7,8,9";
            }
            courser_shixi_information[i][11]="";
            courser_shixi_information[i][12]=(class_room_information[jiaoshi+tag1][0]);
            courser_shixi_information[i][13]="0";
            String sql_change="";

            System.out.println();
            for (int ii=0;ii<courser_shixi_information[i].length;ii++)
                System.out.print(courser_shixi_information[i][ii]+" ");
            change_sql(courser_shixi_information[i]);
//            break;

        }

    }
    //打印模块 用于输出数据库二维数组
    void Print(String temp[][])
    {
        for(int i=0;i<temp.length;i++)
        {
            for(int j=0;j<temp[i].length;j++)
            {
                System.out.print(temp[i][j]+" ");
            }
            System.out.println();
        }

    }

    void shiyan() throws Exception
    {
//        按学时分实验教室类型 四个实验楼ABCD 对应四种学时
//        8，12，18，24
//        2*4，2*6，3*6，3*8
//        所有实验都在第十周开始
        String sql_shiyan="select * from coursesorting where ctype='实验'";       //取出实验课的所有
        ResultSet course_shiyan =  state.executeQuery(sql_shiyan);
        ResultSetMetaData course_shiyan_data = course_shiyan.getMetaData();
        int columncount   = course_shiyan_data.getColumnCount();
        String[][] courser_shiyan_information = new String [1000][1000];
        int shiyan_num=0;
        while(course_shiyan.next())
        {
            String temp_value;
            String[] temp = new String[1000];
            for(int i=0;i<columncount;i++)
            {
                temp_value = course_shiyan.getString(i+1);            //.getString(i) 把每个字段的值取出来
                temp[i]=temp_value;

            }
            courser_shiyan_information[shiyan_num]=temp;
            shiyan_num++;
        }
        int tag_A=0,tag_B=0,tag_C=0,tag_D=0,tag_E=0;
        for(int i =0;i < class_room_num;i++) {
            if (class_room_information[i][1].equals("实验楼A101")) {
                tag_A = i;
            }
            if (class_room_information[i][1].equals("实验楼B101")) {
                tag_B = i;
            }
            if (class_room_information[i][1].equals("实验楼C101")) {
                tag_C = i;
            }
            if (class_room_information[i][1].equals("实验楼D101")) {
                tag_D = i;
            }

            if (class_room_information[i][1].equals("实验楼E101")) {
                tag_E = i;
            }
        }
        one:
        for (int i=0;i<shiyan_num;i++)
        {
            String[] majors=courser_shiyan_information[i][3].split("，");
            String[] class_room=class_room_fix_your_need(Integer.parseInt(courser_shiyan_information[i][6]));
            int id=Integer.parseInt(courser_shiyan_information[i][0]);
            if (course_id_is_use[id]==1) continue;
            if (courser_shiyan_information[i][10].equals("8")) //一次上两节课
            {
                int rand_xingqiji=0;
                boolean flag_is_busy=true;
                while (rand_xingqiji<=120)
                {
                    rand_xingqiji++;
                    int xingqiji=rand.nextInt(5);
                    int rand_time_inter=0;
                    while (rand_time_inter<=24)
                    {
                        rand_time_inter++;
                        int time_inter=rand.nextInt(4);
                        for(String major_ :majors)
                        {
                            int major_id_ = major_id.get(major_.substring(2)).intValue();
                            String nianji = major_.substring(0,2);
                            if (major_is_busy_information[major_id_][daji_judge(nianji)][xingqiji][time_inter][10]==0) // 有空，随机教室
                            {
                                continue;
                            }
                            else {
                                flag_is_busy=false;
                                break;
                            }
                        }
                        if (flag_is_busy==false)  continue;
                        while (true)
                        {
                            int rand_class_room = rand.nextInt(tag_B - tag_A + 1);
                            if (class_is_use_information[tag_A + rand_class_room][xingqiji][time_inter][10] == 0) {
                                int cstart = 10;    //开始周数
                                int cend = 13;  //结束周数
                                for(String major_ :majors) {
                                    int major_id_ = major_id.get(major_.substring(2)).intValue();
                                    String nianji = major_.substring(0, 2);
                                    for (int week=cstart;week<=cend;week++) {
                                        major_is_busy_information[major_id_][daji_judge(nianji)][xingqiji][time_inter][week] = 1;
                                        class_is_use_information[tag_A + rand_class_room][xingqiji][time_inter][week] = 1;
                                    }
                                }
                                courser_shiyan_information[i][7]= "10";
                                courser_shiyan_information[i][8]= "13";
                                course_id_is_use[id]=1;
                                courser_shiyan_information[i][10]= chinese_sign[xingqiji]+","+timeinterToString(time_inter,2);
                                courser_shiyan_information[i][11] = "";
                                courser_shiyan_information[i][12] = (class_room_information[tag_A+rand_class_room][0]);
                                courser_shiyan_information[i][13] = "0";
                                change_sql(courser_shiyan_information[i]);
                                continue one;
                            }
                        }
                    }
                }

            }
            if (courser_shiyan_information[i][10].equals("12")) //2*6
            {
                int rand_xingqiji=0;
                boolean flag_is_busy=true;
                while (rand_xingqiji<=120)
                {
                    rand_xingqiji++;
                    int xingqiji=rand.nextInt(5);
                    int rand_time_inter=0;
                    while (rand_time_inter<=24)
                    {
                        rand_time_inter++;
                        int time_inter=rand.nextInt(4);
                        for(String major_ :majors)
                        {
                            int major_id_ = major_id.get(major_.substring(2)).intValue();
                            String nianji = major_.substring(0,2);
                            if (major_is_busy_information[major_id_][daji_judge(nianji)][xingqiji][time_inter][10]==0) // 有空，随机教室
                            {
                                continue;
                            }
                            else {
                                flag_is_busy=false;
                                break;
                            }
                        }
                        if (flag_is_busy==false)  continue;
                        while (true)
                        {
                            int rand_class_room = rand.nextInt(tag_C - tag_B + 1);
                            if (class_is_use_information[tag_B + rand_class_room][xingqiji][time_inter][10] == 0) {
                                int cstart = 10;    //开始周数
                                int cend = 15;  //结束周数
                                for(String major_ :majors) {
                                    int major_id_ = major_id.get(major_.substring(2)).intValue();
                                    String nianji = major_.substring(0, 2);
                                    for (int week=cstart;week<=cend;week++) {
                                        major_is_busy_information[major_id_][daji_judge(nianji)][xingqiji][time_inter][week] = 1;
                                        class_is_use_information[tag_A + rand_class_room][xingqiji][time_inter][week] = 1;
                                    }
                                }
                                courser_shiyan_information[i][7]= "10";
                                courser_shiyan_information[i][8]= "15";

                                courser_shiyan_information[i][10]= chinese_sign[xingqiji]+","+timeinterToString(time_inter,2);
                                courser_shiyan_information[i][11] = "";
                                courser_shiyan_information[i][12] = (class_room_information[tag_B+rand_class_room][0]);
                                courser_shiyan_information[i][13] = "0";
                                course_id_is_use[id]=1;

                                change_sql(courser_shiyan_information[i]);
                                continue one;
                            }
                        }
                    }
                }
            }
            if (courser_shiyan_information[i][10].equals("18")) //3*6
            {
                int rand_xingqiji=0;
                boolean flag_is_busy=true;
                while (rand_xingqiji<=120)
                {
                    rand_xingqiji++;
                    int xingqiji=rand.nextInt(5);
                    int rand_time_inter=0;
                    while (rand_time_inter<=24)
                    {
                        rand_time_inter++;
                        int time_inter=rand.nextInt(4);
                        if (time_inter==1) continue;
                        for(String major_ :majors)
                        {
                            int major_id_ = major_id.get(major_.substring(2)).intValue();
                            String nianji = major_.substring(0,2);
                            if (major_is_busy_information[major_id_][daji_judge(nianji)][xingqiji][time_inter][10]==0) // 有空，随机教室
                            {
                                continue;
                            }
                            else {
                                flag_is_busy=false;
                                break;
                            }
                        }
                        if (flag_is_busy==false)  continue;
                        while (true)
                        {
                            int rand_class_room = rand.nextInt(tag_D - tag_C + 1);
                            if (class_is_use_information[tag_A + rand_class_room][xingqiji][time_inter][10] == 0) {
                                int cstart = 10;    //开始周数
                                int cend = 15;  //结束周数
                                for(String major_ :majors) {
                                    int major_id_ = major_id.get(major_.substring(2)).intValue();
                                    String nianji = major_.substring(0, 2);
                                    for (int week=cstart;week<=cend;week++) {
                                        major_is_busy_information[major_id_][daji_judge(nianji)][xingqiji][time_inter][week] = 1;
                                        class_is_use_information[tag_C + rand_class_room][xingqiji][time_inter][week] = 1;
                                    }
                                }
                                courser_shiyan_information[i][7]= "10";
                                courser_shiyan_information[i][8]= "15";

                                courser_shiyan_information[i][10]= chinese_sign[xingqiji]+","+timeinterToString(time_inter,3);
                                courser_shiyan_information[i][11] = "";
                                courser_shiyan_information[i][12] = (class_room_information[tag_C+rand_class_room][0]);
                                courser_shiyan_information[i][13] = "0";
                                course_id_is_use[id]=1;

                                change_sql(courser_shiyan_information[i]);
                                continue one;
                            }
                        }
                    }
                }
            }
            if (courser_shiyan_information[i][10].equals("24")) //3*8
            {
                int rand_xingqiji=0;
                boolean flag_is_busy=true;
                while (rand_xingqiji<=120)
                {
                    rand_xingqiji++;
                    int xingqiji=rand.nextInt(5);
                    int rand_time_inter=0;
                    while (rand_time_inter<=24)
                    {
                        rand_time_inter++;
                        int time_inter=rand.nextInt(4);
                        if (time_inter==1) continue;
                        for(String major_ :majors)
                        {
                            int major_id_ = major_id.get(major_.substring(2)).intValue();
                            String nianji = major_.substring(0,2);
                            if (major_is_busy_information[major_id_][daji_judge(nianji)][xingqiji][time_inter][10]==0) // 有空，随机教室
                            {
                                continue;
                            }
                            else {
                                flag_is_busy=false;
                                break;
                            }
                        }
                        if (flag_is_busy==false)  continue;
                        while (true)
                        {
                            int rand_class_room = rand.nextInt(tag_E - tag_D + 1);
                            if (class_is_use_information[tag_A + rand_class_room][xingqiji][time_inter][10] == 0) {
                                int cstart = 10;    //开始周数
                                int cend = 17;  //结束周数
                                for(String major_ :majors) {
                                    int major_id_ = major_id.get(major_.substring(2)).intValue();
                                    String nianji = major_.substring(0, 2);
                                    for (int week=cstart;week<=cend;week++) {
                                        major_is_busy_information[major_id_][daji_judge(nianji)][xingqiji][time_inter][week] = 1;
                                        class_is_use_information[tag_A + rand_class_room][xingqiji][time_inter][week] = 1;
                                    }
                                }
                                courser_shiyan_information[i][7]= "10";
                                courser_shiyan_information[i][8]= "17";

                                courser_shiyan_information[i][10]= chinese_sign[xingqiji]+","+timeinterToString(time_inter,3);
                                courser_shiyan_information[i][11] = "";
                                courser_shiyan_information[i][12] = (class_room_information[tag_D+rand_class_room][0]);
                                courser_shiyan_information[i][13] = "0";
                                course_id_is_use[id]=1;

                                change_sql(courser_shiyan_information[i]);
                                continue one;
                            }
                        }
                    }
                }
            }

        }

    }
    void exam() throws  Exception
    {
        String sql_exam = "select * from coursehistory where (ctype='公共基础必修' OR ctype='专业必修') and year='2016' and semester=1 ORDER  BY  cnum ASC " ;
        ResultSet a_exam = state.executeQuery(sql_exam);
        ResultSetMetaData a_exam_data = a_exam.getMetaData();
        int count = a_exam_data.getColumnCount();
        String[][] exam_information = new String [1000][20];

        int exam_num=0;
        while(a_exam.next())
        {
            String temp_value;
            String[] temp= new String[1000];
            for(int i=0;i<count;i++)
            {
                temp_value = a_exam.getString(i+1);
                temp[i]=temp_value;
            }
            exam_information[exam_num]=temp;
            exam_num++;
        }

        for(int i=0;i<exam_num;i++)
        {

            String class_room_to_exam[]= class_room_fix_your_need(Integer.parseInt(exam_information[i][6]));
            if (i!=0 && exam_information[i][1]==exam_information[i-1][1]) {
                exam_information[i][11]=exam_information[i-1][11];
            }
            int time1 = rand.nextInt(14);//14天中的那一天 、7+19为周数
            int time2 = rand.nextInt(3);//上午下午晚上三个时间段
            System.out.println(class_room_to_exam.length);
            if(class_room_to_exam.length==0) continue;
            int jiaoshi1 = rand.nextInt(class_room_to_exam.length);
            int jiaoshi2 = rand.nextInt(class_room_to_exam.length);
            if((class_is_use_information[jiaoshi1][time1 % 7][time2][time1 / 7 + 19] ==0)&&(class_is_use_information[jiaoshi2][time1 % 7][time2][time1 / 7 + 19] ==0))
            {
                class_is_use_information[jiaoshi1][time1 % 7][time2][time1 / 7 + 19] = 1;
                class_is_use_information[jiaoshi2][time1 % 7][time2][time1 / 7 + 19] = 1;
            }
            else
            {
                i--;
                continue;
            }
            exam_information[i][10]=String.valueOf(time1/7+19);
            exam_information[i][12]=String.valueOf(jiaoshi1);
            exam_information[i][13]=String.valueOf(jiaoshi2);

            System.out.println("time2:"+time2);
            if(time2==0)
            {
                exam_information[i][11]=chinese_sign[time1%7]+","+"8:00-10:00";
            }
            if(time2==1)
            {
                exam_information[i][11]=chinese_sign[time1%7]+","+"13:00-15:00";
            }
            if(time2==2)
            {
                exam_information[i][11]=chinese_sign[time1%7]+","+"18:00-20:00";
            }
            String sql_change="";
            for (int ii=0;ii<4;ii++)
                sql_change = sql_change+"'"+exam_information[i][ii]+"',";
            sql_change = sql_change+"'"+exam_information[i][5]+"',";
            for (int ii=10;ii<13;ii++)
                sql_change = sql_change+"'"+exam_information[i][ii]+"',";
            sql_change = sql_change+"'"+exam_information[i][13]+"'";

            for (int ii=0;ii<exam_information[i].length;ii++)
                System.out.print(exam_information[i][ii]+" ");
            String sql="INSERT INTO `1603_`.`exam`(`id`, `cnum`, `cname`, `cmajor`, `tid`, `week` ,`time`, `classid1`, `classid2`) VALUES ( "+sql_change+")";
            System.out.println(sql);
            state.executeUpdate(sql);
//            change_sql(exam_information[i]);
        }

    }



    zdpk() throws Exception
    {
        Class.forName("com.mysql.jdbc.Driver");
        conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/1603_?useUnicode=true&characterEncoding=UTF-8&useSSL=true", "root", "zhouzhou");
        state = conn.createStatement();
        //init();
        init_major_id();
//        check_class();
//        String clear_sql="delete from course";
//        state.executeUpdate(clear_sql);
//        String init_sql="alter table course AUTO_INCREMENT=1";
//        state.executeUpdate(init_sql);
//        tongshi();
//        tiyu();
//        shiyan();
//        other_course();
       // exam();
        save_txt();




           exam();

    }
}
