package com.cs1603.jwglxt.bean.paike;

public class Course {
    public Integer id;
    public String cnum;
    public String cname;
    public String cmajor;
    public String ctype;
    public String tid;
    public String call;
    public String cstart;
    public String cend;
    public String  credit;
    public String time1;
    public String time2;
    public String cnow;
    public String classid;

    public Course(Integer id, String cnum, String cname, String cmajor, String ctype, String tid, String call, String cstart, String cend, String credit, String time1, String time2, String cnow, String classid) {
        this.id = id;
        this.cnum = cnum;
        this.cname = cname;
        this.cmajor = cmajor;
        this.ctype = ctype;
        this.tid = tid;
        this.call = call;
        this.cstart = cstart;
        this.cend = cend;
        this.credit = credit;
        this.time1 = time1;
        this.time2 = time2;
        this.cnow = cnow;
        this.classid = classid;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getCnum() {
        return cnum;
    }

    public void setCnum(String cnum) {
        this.cnum = cnum;
    }

    public String getCname() {
        return cname;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public String getCmajor() {
        return cmajor;
    }

    public void setCmajor(String cmajor) {
        this.cmajor = cmajor;
    }

    public String getCtype() {
        return ctype;
    }

    public void setCtype(String ctype) {
        this.ctype = ctype;
    }

    public String getTid() {
        return tid;
    }

    public void setTid(String tid) {
        this.tid = tid;
    }

    public String getCall() {
        return call;
    }

    public void setCall(String call) {
        this.call = call;
    }

    public String getCstart() {
        return cstart;
    }

    public void setCstart(String cstart) {
        this.cstart = cstart;
    }

    public String getCend() {
        return cend;
    }

    public void setCend(String cend) {
        this.cend = cend;
    }

    public String getCredit() {
        return credit;
    }

    public void setCredit(String credit) {
        this.credit = credit;
    }

    public String getTime1() {
        return time1;
    }

    public void setTime1(String time1) {
        this.time1 = time1;
    }

    public String getTime2() {
        return time2;
    }

    public void setTime2(String time2) {
        this.time2 = time2;
    }

    public String getCnow() {
        return cnow;
    }

    public void setCnow(String cnow) {
        this.cnow = cnow;
    }

    public String getClassid() {
        return classid;
    }

    public void setClassid(String classid) {
        this.classid = classid;
    }
}