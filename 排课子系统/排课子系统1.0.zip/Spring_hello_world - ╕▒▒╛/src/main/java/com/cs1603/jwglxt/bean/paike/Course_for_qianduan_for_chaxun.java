package com.cs1603.jwglxt.bean.paike;

public class Course_for_qianduan_for_chaxun {
    private String cname="";
    private String tname="";
    private String classname="";
    private String cstart="";
    private String cend="";
    private String time1="";
    private String time2="";
    public Course_for_qianduan_for_chaxun(String cname, String tname, String classname, String cstart, String cend, String time1, String time2) {
        this.cname = cname;
        this.tname = tname;
        this.classname = classname;
        this.cstart = cstart;
        this.cend = cend;
        this.time1 = time1;
        this.time2 = time2;
    }



    public void Course_for_qianduan_for_chaxun_(String cname, String tname, String classname, String cstart, String cend, String time1, String time2) {
        this.cname = cname;
        this.tname = tname;
        this.classname = classname;
        this.cstart = cstart;
        this.cend = cend;
        this.time1 = time1;
        this.time2 = time2;
    }
    public String getTime1() {
        return time1;
    }

    public void setTime1(String time1) {
        this.time1 = time1;
    }

    public void setTime2(String time2) {
        this.time2 = time2;
    }

    public String getTime2() {
        return time2;
    }

    public String getCname() {
        return cname;
    }

    public String getTname() {
        return tname;
    }

    public String getClassname() {
        return classname;
    }

    public String getCstart() {
        return cstart;
    }

    public String getCend() {
        return cend;
    }

    public void setCname(String cname) {
        this.cname = cname;
    }

    public void setTname(String tname) {
        this.tname = tname;
    }

    public void setClassname(String classname) {
        this.classname = classname;
    }

    public void setCstart(String cstart) {
        this.cstart = cstart;
    }

    public void setCend(String cend) {
        this.cend = cend;
    }
}
