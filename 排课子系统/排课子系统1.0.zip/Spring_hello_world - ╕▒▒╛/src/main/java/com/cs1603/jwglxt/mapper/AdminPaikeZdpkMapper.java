package com.cs1603.jwglxt.mapper;

import com.cs1603.jwglxt.bean.paike.Course;
import com.cs1603.jwglxt.bean.paike.Course_zdpk;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;


public interface AdminPaikeZdpkMapper {
    @Select("select * from course")
    public Course_zdpk[] is_alreay_paike();
}
