package com.cs1603.jwglxt.mapper;

import com.cs1603.jwglxt.bean.paike.Course_for_qianduan_for_chaxun;
import com.cs1603.jwglxt.bean.paike.Coursehistory;
import com.cs1603.jwglxt.bean.paike.Result;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

public interface CommonPaikeMajor_find_courseMapper {
    @Select("select coursehistory.cname,teacher.tname,classroom.classname,coursehistory.cstart,coursehistory.cend,coursehistory.time1,coursehistory.time2 from coursehistory,classroom,teacher where coursehistory.tid=teacher.tid and coursehistory.classid=classroom.classid and   year=#{year} and semester=#{semester} and coursehistory.cmajor like '%${cmajor}%' ")
   // @Select("select * from coursehistory where year=#{year} and semester=#{semester}  and cmajor like '%${cmajor}%' ")
    public Course_for_qianduan_for_chaxun[] major_find_course(@Param("year") String year, @Param("semester") Integer semester, @Param("cmajor") String cmajor);
}
